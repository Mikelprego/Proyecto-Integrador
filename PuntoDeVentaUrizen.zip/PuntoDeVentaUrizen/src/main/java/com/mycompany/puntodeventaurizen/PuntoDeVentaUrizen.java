package com.mycompany.puntodeventaurizen;

public class PuntoDeVentaUrizen {
    public static void main(String[] args) {
        
    }
}
