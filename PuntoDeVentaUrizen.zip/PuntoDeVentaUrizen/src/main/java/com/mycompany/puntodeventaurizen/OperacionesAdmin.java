
package com.mycompany.puntodeventaurizen;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;

public class OperacionesAdmin extends javax.swing.JFrame {

    public OperacionesAdmin() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnInventario = new javax.swing.JButton();
        verVentas = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        btnAtrasLogin = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        btnNotificaciones = new javax.swing.JButton();
        btnAgregarUsuario = new javax.swing.JButton();

        jButton2.setText("jButton2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/HacerHoy2.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        btnInventario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/verInventario.png"))); // NOI18N
        btnInventario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventarioActionPerformed(evt);
            }
        });
        jPanel1.add(btnInventario, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 317, 37));

        verVentas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/VerVentas.png"))); // NOI18N
        verVentas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        verVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                verVentasActionPerformed(evt);
            }
        });
        jPanel1.add(verVentas, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 130, 249, 34));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/verPedidos.png"))); // NOI18N
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 262, 30));

<<<<<<< HEAD
        btnAtrasLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/home.png"))); // NOI18N
=======
        btnAtrasLogin.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\exit.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnAtrasLogin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAtrasLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasLoginActionPerformed(evt);
            }
        });
<<<<<<< HEAD
        jPanel1.add(btnAtrasLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 420, 80, 70));

        btnActualizarExistencias.setBackground(new java.awt.Color(0, 0, 0));
        btnActualizarExistencias.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/ActualizarExistencias.png"))); // NOI18N
        btnActualizarExistencias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnActualizarExistencias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarExistenciasActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizarExistencias, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 370, 40));
=======
        jPanel1.add(btnAtrasLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 80, 70));
>>>>>>> 33d3918 (Actualizar proyecto)

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/pequeño 200.jpeg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 300, -1, -1));

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_proveedore imagen.png")); // NOI18N
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 280, 40));

        btnNotificaciones.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_campana.png")); // NOI18N
        btnNotificaciones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnNotificaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotificacionesActionPerformed(evt);
            }
        });
        jPanel1.add(btnNotificaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 420, 80, 80));

        btnAgregarUsuario.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_nuevousuario.png")); // NOI18N
        btnAgregarUsuario.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAgregarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgregarUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 260, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 655, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 528, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasLoginActionPerformed

      int opcion = JOptionPane.showConfirmDialog(
      null,
      "¿Deseas cerrar sesión e ir al login?",
      "Confirmar acción",
      JOptionPane.YES_NO_OPTION
       );

      if (opcion == JOptionPane.YES_OPTION) {
      Login lg = new Login();
      lg.setVisible(true);
      this.setVisible(false);
      }
    }//GEN-LAST:event_btnAtrasLoginActionPerformed

    private void btnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventarioActionPerformed
        
        VerInventario vi = new VerInventario ();
        vi.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_btnInventarioActionPerformed

    private void verVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_verVentasActionPerformed
        
        VerVentas vv = new VerVentas ();
        vv.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_verVentasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        VerPedidos vp = new VerPedidos ();
        vp.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        Proveedores pro = new Proveedores();
        pro.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnNotificacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotificacionesActionPerformed
        
         LocalDate hoy = LocalDate.now();

    // Mapa de fechas importantes (puedes agregar más)
    Map<String, LocalDate> fechasImportantes = new HashMap<>();
    int año = hoy.getYear();

    fechasImportantes.put("Día del Niño", LocalDate.of(año, Month.APRIL, 30));
    fechasImportantes.put("Día de las Madres", LocalDate.of(año, Month.MAY, 10));
    fechasImportantes.put("Día del Padre", LocalDate.of(año, Month.JUNE, hoy.withMonth(6).withDayOfMonth(1).with(java.time.DayOfWeek.SUNDAY).plusWeeks(2).getDayOfMonth())); // tercer domingo
    fechasImportantes.put("Día de la Independencia", LocalDate.of(año, Month.SEPTEMBER, 16));
    fechasImportantes.put("Día de Muertos", LocalDate.of(año, Month.NOVEMBER, 2));
    fechasImportantes.put("Navidad", LocalDate.of(año, Month.DECEMBER, 25));

    boolean encontrado = false;

    for (Map.Entry<String, LocalDate> entry : fechasImportantes.entrySet()) {
        String nombre = entry.getKey();
        LocalDate fecha = entry.getValue();

        long diasFaltantes = ChronoUnit.DAYS.between(hoy, fecha);

        if (diasFaltantes >= 0 && diasFaltantes <= 21) {
            JOptionPane.showMessageDialog(null, "¡Se acerca " + nombre + " en " + diasFaltantes + " días!\nComienza a preparar mercancía.");
            encontrado = true;
            break; // solo muestra el más cercano
        }
    }

    if (!encontrado) {
        JOptionPane.showMessageDialog(null, "No hay días especiales cerca.");
    }
    }//GEN-LAST:event_btnNotificacionesActionPerformed

    private void btnAgregarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarUsuarioActionPerformed
        // TODO add your handling code here:
        AgregarUsuario ag = new AgregarUsuario();
        ag.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btnAgregarUsuarioActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OperacionesAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregarUsuario;
    private javax.swing.JButton btnAtrasLogin;
    private javax.swing.JButton btnInventario;
    private javax.swing.JButton btnNotificaciones;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton verVentas;
    // End of variables declaration//GEN-END:variables
}
