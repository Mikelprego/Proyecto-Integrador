package com.mycompany.puntodeventaurizen;

import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.security.NoSuchAlgorithmException;

public class Login extends javax.swing.JFrame {   
    public Login() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnSalirPrograma = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        passContraseña = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        txtUsuario = new javax.swing.JTextField();
        btnLoginear = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        btnSalirPrograma1 = new javax.swing.JButton();

        btnSalirPrograma.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\salirchico.png")); // NOI18N
        btnSalirPrograma.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSalirPrograma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirProgramaActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

<<<<<<< HEAD
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/Contraseña.png"))); // NOI18N
=======
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\Contraseña.png")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));
>>>>>>> 33d3918 (Actualizar proyecto)

        passContraseña.setForeground(new java.awt.Color(153, 153, 153));
        passContraseña.setBorder(null);
        passContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passContraseñaActionPerformed(evt);
            }
        });
        jPanel1.add(passContraseña, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 290, 164, 24));

<<<<<<< HEAD
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/usuario.png"))); // NOI18N
=======
        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\usuario.png")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, -1, -1));
>>>>>>> 33d3918 (Actualizar proyecto)

        txtUsuario.setForeground(new java.awt.Color(153, 153, 153));
        txtUsuario.setToolTipText("");
        txtUsuario.setBorder(null);
        jPanel1.add(txtUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(318, 238, 164, 26));

<<<<<<< HEAD
        btnLoginear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/LoginPequeño.png"))); // NOI18N
        btnLoginear.setText("jButton1");
        btnLoginear.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
=======
        btnLoginear.setBackground(new java.awt.Color(0, 0, 0));
        btnLoginear.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\LoginPequeño.png")); // NOI18N
        btnLoginear.setBorder(null);
        btnLoginear.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btnLoginear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLoginearMouseClicked(evt);
            }
        });
>>>>>>> 33d3918 (Actualizar proyecto)
        btnLoginear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginearActionPerformed(evt);
            }
        });
<<<<<<< HEAD

        btnAtrasLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/home.png"))); // NOI18N
        btnAtrasLogin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAtrasLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAtrasLoginMouseClicked(evt);
            }
        });
        btnAtrasLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasLoginActionPerformed(evt);
            }
        });

        jLabel3.setForeground(new java.awt.Color(255, 255, 102));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/pequeño 200.jpeg"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(221, 221, 221)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(128, 128, 128)
                                .addComponent(jLabel2))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel1))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(btnAtrasLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnLoginear, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                                .addComponent(passContraseña)))))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2)
                    .addComponent(txtUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(passContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(37, 37, 37)
                .addComponent(btnLoginear, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11)
                .addComponent(btnAtrasLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
=======
        jPanel1.add(btnLoginear, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 340, 136, 42));

        jLabel3.setForeground(new java.awt.Color(255, 255, 102));
        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\pequeño 200.jpeg")); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(219, 6, 201, 191));

        btnSalirPrograma1.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\salirchico.png")); // NOI18N
        btnSalirPrograma1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSalirPrograma1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirPrograma1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnSalirPrograma1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, 50));
>>>>>>> 33d3918 (Actualizar proyecto)

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 490));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoginearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginearActionPerformed

        try {
    String usuarioIngresado = txtUsuario.getText();
    String contrasenaIngresada = new String(passContraseña.getPassword());
    if (usuarioIngresado.isEmpty() || contrasenaIngresada.isEmpty()) {
        JOptionPane.showMessageDialog(null, "Ingresa usuario y contraseña.");
        return;
    }
    
    String contrasenaHash = encriptarSHA256(contrasenaIngresada);
    Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/uri", "root", "root123");
    String sql = "SELECT rol FROM users WHERE nombreUsuario = ? AND contrasena = ?";
    PreparedStatement stmt = con.prepareStatement(sql);
    stmt.setString(1, usuarioIngresado);
    stmt.setString(2, contrasenaHash);

    ResultSet rs = stmt.executeQuery();

    if (rs.next()) {
        String rol = rs.getString("rol");

        JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");

        if (rol.equalsIgnoreCase("Administrador")) {
            OperacionesAdmin opa = new OperacionesAdmin();
            opa.setVisible(true);
        } else if (rol.equalsIgnoreCase("Empleado")) {
            OperacionesJFrame jf = new OperacionesJFrame();
            jf.setVisible(true);
        }

        this.setVisible(false);
    } else {
        JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos", "Error de acceso", JOptionPane.ERROR_MESSAGE);
    }

    con.close();

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error al iniciar sesión.");
}

    }//GEN-LAST:event_btnLoginearActionPerformed

    private void btnSalirProgramaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirProgramaActionPerformed
        int opcion = JOptionPane.showConfirmDialog(this, "¿Seguro que deseas salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);

        }
    }//GEN-LAST:event_btnSalirProgramaActionPerformed

    private void btnSalirPrograma1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirPrograma1ActionPerformed
        
        int opcion = JOptionPane.showConfirmDialog(this, "¿Seguro que deseas salir?", "Confirmar salida", JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            System.exit(0);

        }
    }//GEN-LAST:event_btnSalirPrograma1ActionPerformed

    private void btnLoginearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLoginearMouseClicked

    }//GEN-LAST:event_btnLoginearMouseClicked

    private void passContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passContraseñaActionPerformed

    
    public String encriptarSHA256(String contraseña) {
    try {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(contraseña.getBytes("UTF-8"));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
   }
  
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLoginear;
    private javax.swing.JButton btnSalirPrograma;
    private javax.swing.JButton btnSalirPrograma1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField passContraseña;
    private javax.swing.JTextField txtUsuario;
    // End of variables declaration//GEN-END:variables
}
