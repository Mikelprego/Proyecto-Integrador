
package com.mycompany.puntodeventaurizen;

import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VerInventario extends javax.swing.JFrame {

    Conexion cone = new Conexion();
    Connection con;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    
    public VerInventario() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null); 
        consultarInventario();       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnAtrasOperAdmin = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla3 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

<<<<<<< HEAD
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/verInventario.png"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 30, -1, -1));

        btnAtrasOperAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/home.png"))); // NOI18N
=======
        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\inventario89.png")); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, -1, -1));

        btnAtrasOperAdmin.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\flechaChida1.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnAtrasOperAdmin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAtrasOperAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasOperAdminActionPerformed(evt);
            }
        });
        jPanel2.add(btnAtrasOperAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 437, 80, 80));

        Tabla3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id_Producto", "Id_Proveedor", "Nombre_Producto", "Tipo_Producto", "Material_Producto", "Descripcion_Producto", "Talla_Producto", "Cantidad_Disponible"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla3);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 790, 320));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 841, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 543, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasOperAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasOperAdminActionPerformed

        OperacionesAdmin opa = new OperacionesAdmin ();
        opa.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btnAtrasOperAdminActionPerformed

    void consultarInventario(){
    String sql = "SELECT * FROM uri.producto";
    try {
        con = cone.conectar();
        st = con.createStatement();
        rs = st.executeQuery(sql);
        modelo = (DefaultTableModel)Tabla3.getModel();
        modelo.setRowCount(0); 

        Object[] producto = new Object[8];

        while (rs.next()) {
            producto[0] = rs.getInt("Id_Producto");
            producto[1] = rs.getString("Id_Proveedor");
            producto[2] = rs.getString("Nombre_Producto");
            producto[3] = rs.getString("Tipo_Producto");
            producto[4] = rs.getString("Material_Producto");
            producto[5] = rs.getString("Descripcion_Producto");
            producto[6] = rs.getString("Talla_Producto");
            producto[7] = rs.getInt("Cantidad_Disponible");
            modelo.addRow(producto);
        }

    } catch (Exception e) {
        System.out.println("Error al mostrar datos: " + e.getMessage());
    }
}
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerInventario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla3;
    private javax.swing.JButton btnAtrasOperAdmin;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
