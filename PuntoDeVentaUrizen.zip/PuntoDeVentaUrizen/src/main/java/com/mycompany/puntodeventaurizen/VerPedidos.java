package com.mycompany.puntodeventaurizen;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class VerPedidos extends javax.swing.JFrame {

    Conexion cone = new Conexion();
    Connection con;
    DefaultTableModel modelo;
    Statement st;
    ResultSet rs;
    
    public VerPedidos() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        verificarEntregasCercanas();
        consultarpe();
        colorearEstatus();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnAtrasOperacionAdmin = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tabla2 = new javax.swing.JTable();
        btnBorrarPedidos = new javax.swing.JButton();
        btnActualizarPedidos = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

<<<<<<< HEAD
        btnAtrasOperacionAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/home.png"))); // NOI18N
=======
        btnAtrasOperacionAdmin.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\flechaChida1.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnAtrasOperacionAdmin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAtrasOperacionAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasOperacionAdminActionPerformed(evt);
            }
        });
        jPanel1.add(btnAtrasOperacionAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, -1, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/verPedidos.png"))); // NOI18N
        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 16, -1, -1));

        Tabla2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Id_Pedido", "Id_Cliente", "Adelanto", "Restante", "Fecha_Pedido", "Fecha_Entrega", "Encargo", "Telefono", "Estatus"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(Tabla2);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 850, 300));

        btnBorrarPedidos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/borrar.png"))); // NOI18N
        btnBorrarPedidos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnBorrarPedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBorrarPedidosActionPerformed(evt);
            }
        });
        jPanel1.add(btnBorrarPedidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 430, -1, 90));

        btnActualizarPedidos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/refrescar.png"))); // NOI18N
        btnActualizarPedidos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnActualizarPedidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarPedidosActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizarPedidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 430, -1, -1));

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\ActualizarPedido.png")); // NOI18N
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 430, 80, 80));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 925, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 561, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasOperacionAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasOperacionAdminActionPerformed

        OperacionesAdmin opa = new OperacionesAdmin ();
        opa.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btnAtrasOperacionAdminActionPerformed

    private void btnBorrarPedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBorrarPedidosActionPerformed
       eliminar();
       limpiarTabla();
    }//GEN-LAST:event_btnBorrarPedidosActionPerformed

    private void btnActualizarPedidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarPedidosActionPerformed
        verificarEntregasCercanas();
        consultarpe();
    }//GEN-LAST:event_btnActualizarPedidosActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int fila = Tabla2.getSelectedRow();

        if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Selecciona un pedido para actualizar su estatus.");
        return;
        }

        String[] opciones = {"Terminado", "Cancelado", "En proceso"};
        String nuevoEstatus = (String) JOptionPane.showInputDialog(
            null,
            "Selecciona el nuevo estatus:",
            "Actualizar Estatus",
            JOptionPane.QUESTION_MESSAGE,
            null,
            opciones,
            opciones[0]);

        if (nuevoEstatus != null) {
        try {
            int idPedido = Integer.parseInt(Tabla2.getValueAt(fila, 0).toString());
            String sql = "UPDATE pe SET Estatus=? WHERE Id_Pedido=?";
            con = cone.conectar();
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, nuevoEstatus);
            stmt.setInt(2, idPedido);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Estatus actualizado a: " + nuevoEstatus);

            stmt.close();
            con.close();

            // Refrescar tabla
            consultarpe();

         } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al actualizar el estatus: " + e.getMessage());
        }
    }//GEN-LAST:event_jButton1ActionPerformed
  }
    void eliminar() {
    int fila = Tabla2.getSelectedRow();

    // Verificar si hay una fila seleccionada
    if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor selecciona un pedido para eliminar.");
        return;
    }

    // Confirmar eliminación
    int confirmacion = JOptionPane.showConfirmDialog(
        null,"¿Estás seguro que deseas eliminar este pedido?","Confirmar eliminación",JOptionPane.YES_NO_OPTION);

    if (confirmacion == JOptionPane.YES_OPTION) {
        try {
            int idPedido = Integer.parseInt(Tabla2.getValueAt(fila, 0).toString());
            String sql = "DELETE FROM pe WHERE Id_Pedido=" + idPedido;

            con = cone.conectar();         // Conexión
            st = con.createStatement();    // Crear statement
            st.executeUpdate(sql);         // Ejecutar eliminación

            JOptionPane.showMessageDialog(null, "Pedido cancelado correctamente.");
        } catch (Exception e) {
            System.out.println("Error al eliminar el pedido: " + e.getMessage());
        }
    }
}

    
     void limpiarTabla() {
     for (int i = Tabla2.getRowCount() - 1; i >= 0; i--) {
        modelo.removeRow(i);
     }
}

    public static void main(String args[]) {


        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerPedidos().setVisible(true);
            }
        });
    }

void consultarpe() {
    String sql = "SELECT * FROM pe";
    try {
        con = cone.conectar(); 
        st = con.createStatement();
        rs = st.executeQuery(sql);
        modelo = (DefaultTableModel) Tabla2.getModel();
        modelo.setRowCount(0); 
        Object[] pe = new Object[9];  

        while (rs.next()) {
            pe[0] = rs.getInt("Id_Pedido");
            pe[1] = rs.getString("Id_Cliente");
            pe[2] = rs.getString("Adelanto");
            pe[3] = rs.getString("Restante");
            pe[4] = rs.getString("Fecha_Pedido");
            pe[5] = rs.getString("Fecha_Entrega");
            pe[6] = rs.getString("Encargo");
            pe[7] = rs.getString("Telefono");
            pe[8] = rs.getString("Estatus");
            modelo.addRow(pe);
        }
    } catch (Exception e) {
        System.out.println("Error al mostrar datos: " + e.getMessage());
    } finally {
        try { if (rs != null) rs.close(); } catch (Exception e) {}
        try { if (st != null) st.close(); } catch (Exception e) {}
        try { if (con != null) con.close(); } catch (Exception e) {}
    }
}

private void verificarEntregasCercanas() {
    String sql = "SELECT Encargo, Fecha_Entrega FROM pe WHERE DATEDIFF(Fecha_Entrega, CURDATE()) BETWEEN 0 AND 2";
    try {
        con = cone.conectar(); 
        PreparedStatement stmt = con.prepareStatement(sql);
        rs = stmt.executeQuery();

        StringBuilder mensaje = new StringBuilder();
        while (rs.next()) {
            String producto = rs.getString("Encargo");
            java.sql.Date fecha = rs.getDate("Fecha_Entrega");
            mensaje.append("→ ").append(producto).append(" se entregará el ").append(fecha).append("\n");
        }

        if (mensaje.length() > 0) {
            JOptionPane.showMessageDialog(null, 
                "Tienes pedidos próximos a entregarse:\n\n" + mensaje.toString(), 
                "Aviso de entregas cercanas", 
                JOptionPane.INFORMATION_MESSAGE);
        }

        rs.close();
        stmt.close();
        con.close();

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Error al buscar entregas próximas: " + ex.getMessage());
    }
}

    private void colorearEstatus() {
    Tabla2.getColumnModel().getColumn(8).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
        @Override
        public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column){
            java.awt.Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            if (value != null) {
                String estatus = value.toString();
                switch (estatus) {
                    case "Terminado":
                        c.setForeground(new java.awt.Color(0, 153, 0)); // Verde
                        break;
                    case "Cancelado":
                        c.setForeground(java.awt.Color.RED);
                        break;
                    case "En proceso":
                        c.setForeground(new java.awt.Color(255, 153, 0)); // Naranja
                        break;
                    default:
                        c.setForeground(java.awt.Color.BLACK);
                        break;
                }
            }
            if (isSelected) {
                c.setBackground(table.getSelectionBackground());
            } else {
                c.setBackground(java.awt.Color.WHITE);
            }
            return c;
        }
    });
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable Tabla2;
    private javax.swing.JButton btnActualizarPedidos;
    private javax.swing.JButton btnAtrasOperacionAdmin;
    private javax.swing.JButton btnBorrarPedidos;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
