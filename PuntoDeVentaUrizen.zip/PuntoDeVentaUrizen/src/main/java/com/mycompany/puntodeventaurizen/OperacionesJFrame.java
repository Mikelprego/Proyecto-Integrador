
package com.mycompany.puntodeventaurizen;

import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class OperacionesJFrame extends javax.swing.JFrame {

    
    public OperacionesJFrame() {
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnIngresarVenta = new javax.swing.JButton();
        btnIngresarPedido = new javax.swing.JButton();
        btnAtrasInicio = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
<<<<<<< HEAD
        jLabel3 = new javax.swing.JLabel();
=======
        btnActualizarExistencias = new javax.swing.JButton();
        btnNotificaciones = new javax.swing.JButton();
        btnLinkFacebook = new javax.swing.JButton();
        btnLinkInstagram = new javax.swing.JButton();
        btnLinkTiktok = new javax.swing.JButton();
>>>>>>> 33d3918 (Actualizar proyecto)

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

<<<<<<< HEAD
        btnAdmin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/user.png"))); // NOI18N
        btnAdmin.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminActionPerformed(evt);
            }
        });
        jPanel1.add(btnAdmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 400, 90, 80));

=======
>>>>>>> 33d3918 (Actualizar proyecto)
        jLabel1.setFont(new java.awt.Font("Javanese Text", 3, 24)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/HacerHoy2.png"))); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 23, 609, 49));

        btnIngresarVenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/IngresarVenta2.png"))); // NOI18N
        btnIngresarVenta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnIngresarVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarVentaActionPerformed(evt);
            }
        });
        jPanel1.add(btnIngresarVenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 253, 35));

        btnIngresarPedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/IngresarPedido2.png"))); // NOI18N
        btnIngresarPedido.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnIngresarPedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarPedidoActionPerformed(evt);
            }
        });
        jPanel1.add(btnIngresarPedido, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, 266, 38));

<<<<<<< HEAD
        btnAtrasInicio.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/home.png"))); // NOI18N
=======
        btnAtrasInicio.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\exit.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnAtrasInicio.setBorder(new javax.swing.border.MatteBorder(null));
        btnAtrasInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasInicioActionPerformed(evt);
            }
        });
<<<<<<< HEAD
        jPanel1.add(btnAtrasInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, 80, 70));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 290, -1, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/mycompany/IMG/pequeño 200.jpeg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 290, -1, -1));
=======
        jPanel1.add(btnAtrasInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, 80, 70));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\pequeño 200.jpeg")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 290, -1, -1));

        btnActualizarExistencias.setBackground(new java.awt.Color(0, 0, 0));
        btnActualizarExistencias.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\ActualizarExistencias.png")); // NOI18N
        btnActualizarExistencias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnActualizarExistencias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarExistenciasActionPerformed(evt);
            }
        });
        jPanel1.add(btnActualizarExistencias, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 200, 370, 40));

        btnNotificaciones.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_campana.png")); // NOI18N
        btnNotificaciones.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnNotificaciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotificacionesActionPerformed(evt);
            }
        });
        jPanel1.add(btnNotificaciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 80, 80));

        btnLinkFacebook.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_facebook.png")); // NOI18N
        btnLinkFacebook.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLinkFacebook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLinkFacebookActionPerformed(evt);
            }
        });
        jPanel1.add(btnLinkFacebook, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 390, 90, 80));

        btnLinkInstagram.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_instagram.png")); // NOI18N
        btnLinkInstagram.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLinkInstagram.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLinkInstagramActionPerformed(evt);
            }
        });
        jPanel1.add(btnLinkInstagram, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 390, 80, 80));

        btnLinkTiktok.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_tiktok.png")); // NOI18N
        btnLinkTiktok.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnLinkTiktok.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLinkTiktokActionPerformed(evt);
            }
        });
        jPanel1.add(btnLinkTiktok, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 390, 90, 80));
>>>>>>> 33d3918 (Actualizar proyecto)

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIngresarVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarVentaActionPerformed
        
        IngresarVenta iv = new IngresarVenta();
        iv.setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_btnIngresarVentaActionPerformed

    private void btnIngresarPedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarPedidoActionPerformed
        IngresarPedido ip = new IngresarPedido();
        ip.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_btnIngresarPedidoActionPerformed

    private void btnAtrasInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasInicioActionPerformed
      
      int opcion = JOptionPane.showConfirmDialog(
      null,
      "¿Deseas cerrar sesión e ir al login?",
      "Confirmar acción",
      JOptionPane.YES_NO_OPTION
       );

      if (opcion == JOptionPane.YES_OPTION) {
      Login lg = new Login();
      lg.setVisible(true);
      this.setVisible(false);
      }
      
    }//GEN-LAST:event_btnAtrasInicioActionPerformed

    private void btnActualizarExistenciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarExistenciasActionPerformed

        ActualizarExistencias AcE = new ActualizarExistencias ();
        AcE.setVisible(true);
        this.setVisible(false);

    }//GEN-LAST:event_btnActualizarExistenciasActionPerformed

    private void btnNotificacionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotificacionesActionPerformed

        LocalDate hoy = LocalDate.now();
        Map<String, LocalDate> fechasImportantes = new HashMap<>();
        int año = hoy.getYear();
        fechasImportantes.put("Día del Niño", LocalDate.of(año, Month.APRIL, 30));
        fechasImportantes.put("Día de las Madres", LocalDate.of(año, Month.MAY, 10));
        fechasImportantes.put("Día del Padre", LocalDate.of(año, Month.JUNE, hoy.withMonth(6).withDayOfMonth(1).with(java.time.DayOfWeek.SUNDAY).plusWeeks(2).getDayOfMonth())); // tercer domingo
        fechasImportantes.put("Día de la Independencia", LocalDate.of(año, Month.SEPTEMBER, 16));
        fechasImportantes.put("Día de Muertos", LocalDate.of(año, Month.NOVEMBER, 2));
        fechasImportantes.put("Navidad", LocalDate.of(año, Month.DECEMBER, 25));
        boolean encontrado = false;

        for (Map.Entry<String, LocalDate> entry : fechasImportantes.entrySet()) {
            String nombre = entry.getKey();
            LocalDate fecha = entry.getValue();

            long diasFaltantes = ChronoUnit.DAYS.between(hoy, fecha);

            if (diasFaltantes >= 0 && diasFaltantes <= 21) {
                JOptionPane.showMessageDialog(null, "¡Se acerca " + nombre + " en " + diasFaltantes + " días!\nComienza a preparar mercancía.");
                encontrado = true;
                break; // solo muestra el más cercano
            }
        }

        if (!encontrado) {
            JOptionPane.showMessageDialog(null, "No hay días especiales cerca.");
        }
    }//GEN-LAST:event_btnNotificacionesActionPerformed

    private void btnLinkFacebookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLinkFacebookActionPerformed
        try {
        Desktop.getDesktop().browse(new URI("https://www.facebook.com/share/199mzzyX9N/"));
        } catch (IOException | URISyntaxException e) {
        e.printStackTrace();
        }
    }//GEN-LAST:event_btnLinkFacebookActionPerformed

    private void btnLinkInstagramActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLinkInstagramActionPerformed
        try {
        Desktop.getDesktop().browse(new URI("https://www.instagram.com/urizenms?igsh=MTZ6M2J4bXBsYzRoZg=="));
        } catch (IOException | URISyntaxException e) {
        e.printStackTrace();
        }
    }//GEN-LAST:event_btnLinkInstagramActionPerformed

    private void btnLinkTiktokActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLinkTiktokActionPerformed
        try {
        Desktop.getDesktop().browse(new URI("https://www.tiktok.com/@urizenms?_t=ZS-8yUJ4WE3Xsm&_r=1"));
        } catch (IOException | URISyntaxException e) {
        e.printStackTrace();
        }
    }//GEN-LAST:event_btnLinkTiktokActionPerformed

    public static void main(String args[]) {  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OperacionesJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarExistencias;
    private javax.swing.JButton btnAtrasInicio;
    private javax.swing.JButton btnIngresarPedido;
    private javax.swing.JButton btnIngresarVenta;
    private javax.swing.JButton btnLinkFacebook;
    private javax.swing.JButton btnLinkInstagram;
    private javax.swing.JButton btnLinkTiktok;
    private javax.swing.JButton btnNotificaciones;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
