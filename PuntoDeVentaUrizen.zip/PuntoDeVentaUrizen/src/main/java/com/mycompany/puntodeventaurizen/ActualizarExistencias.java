
package com.mycompany.puntodeventaurizen;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ActualizarExistencias extends javax.swing.JFrame {

    public ActualizarExistencias() {
        initComponents();
        setLocationRelativeTo(null);
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnAtrasAcE = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnSubirExistencias = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtProveedor = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        cmbTalla = new javax.swing.JComboBox<>();
        cmbCategoria = new javax.swing.JComboBox<>();
        cmbTipo = new javax.swing.JComboBox<>();
        cmbInsertarProducto = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

<<<<<<< HEAD
        btnAtrasAcE.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\home.png")); // NOI18N
=======
        btnAtrasAcE.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\flechaChida1.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnAtrasAcE.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnAtrasAcE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAtrasAcEActionPerformed(evt);
            }
        });
<<<<<<< HEAD
        jPanel1.add(btnAtrasAcE, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 457, 80, 70));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 27, 425, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\ActualizarExistencias2.png")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 88, 425, 35));

        cmbActualizar.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Playera  Lisa", "Playera Rock ", "Sudadera", "Corset", "Falda", "Playera Sublimada Unitalla", "Playera Sublimada Niño ", "Playera Sublimada Extra Grande", "Tarjetas", "Piezas de Perforaciones", "Pulseras", " " }));
        cmbActualizar.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(cmbActualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 142, 35));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\Cantidad.png")); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        txtCantidad.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 180, 90, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\Talla.png")); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 140, 40));

        cmbTalla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chica", "Mediana", "Grande", "Extra Grande", " " }));
        cmbTalla.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.add(cmbTalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 110, 30));

        btnSubirExistencias.setBackground(new java.awt.Color(0, 0, 0));
        btnSubirExistencias.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\subirpedido.png")); // NOI18N
=======
        jPanel1.add(btnAtrasAcE, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 80, 70));

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\ActualizarExistencias2.png")); // NOI18N
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 27, 580, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\ProductoActualizar.png")); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, 160, 35));

        jLabel3.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\Cantidad.png")); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 160, 180, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\Talla.png")); // NOI18N
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, 140, 30));

        btnSubirExistencias.setBackground(new java.awt.Color(0, 0, 0));
        btnSubirExistencias.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_Aceptar.png")); // NOI18N
>>>>>>> 33d3918 (Actualizar proyecto)
        btnSubirExistencias.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSubirExistencias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubirExistenciasActionPerformed(evt);
            }
        });
        jPanel1.add(btnSubirExistencias, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 440, 220, 50));

<<<<<<< HEAD
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\Admin\\Documents\\clon\\Proyecto-Integrador\\src\\main\\java\\com\\mycompany\\IMG\\pequeño 200.jpeg")); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 330, -1, -1));
=======
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\pequeño 200.jpeg")); // NOI18N
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 320, 180, 190));
>>>>>>> 33d3918 (Actualizar proyecto)

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_categoria.png")); // NOI18N
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_tipo.png")); // NOI18N
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 240, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_descripcion.png")); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 200, 30));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\UrizenMetalShop\\img_proveedor.png")); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 340, -1, -1));
        jPanel1.add(txtProveedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, 180, -1));
        jPanel1.add(txtCantidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 160, 200, -1));
        jPanel1.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 280, 180, -1));

        cmbTalla.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chica", "Mediana", "Grande", "Extra Grande", "XXL", "XXXL", "No talla" }));
        jPanel1.add(cmbTalla, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 120, -1, -1));

        cmbCategoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Ropa", "Accesorios" }));
        jPanel1.add(cmbCategoria, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 200, -1, -1));

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Algodon", "Sublimacion", "Mesa" }));
        jPanel1.add(cmbTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, -1, -1));

        cmbInsertarProducto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Playera Rock", "Playera Anime", "Playera Sublimada", "Taza", "Termo", "Peluche", "Playera sin mangas", "Zig Zag", "Pipa ", "Funko", "Funko Chico ", "Medias de Red", "Gorro", "Collar", "Pulsera", "Falda", "Short", "Pantalon", "Moledor (Grindr)", "Rompecabezas", "Sudadera" }));
        cmbInsertarProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbInsertarProductoActionPerformed(evt);
            }
        });
        jPanel1.add(cmbInsertarProducto, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 80, 210, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 530));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAtrasAcEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtrasAcEActionPerformed

        OperacionesJFrame jf = new OperacionesJFrame();
            jf.setVisible(true);
            this.setVisible(false);
        
    }//GEN-LAST:event_btnAtrasAcEActionPerformed

    private void btnSubirExistenciasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubirExistenciasActionPerformed
    
        insertarProducto();

    }//GEN-LAST:event_btnSubirExistenciasActionPerformed

    private void cmbInsertarProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbInsertarProductoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbInsertarProductoActionPerformed

    private void insertarProducto() {
        try {
        Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/uri", "root", "root123");
        String sql = "INSERT INTO producto (Id_Proveedor, Nombre_Producto, Tipo_Producto, Material_Producto, Descripcion_Producto, Talla_Producto, Cantidad_Disponible) VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, txtProveedor.getText()); // Id_Proveedor
        ps.setString(2, cmbInsertarProducto.getSelectedItem().toString()); // Nombre_Producto
        ps.setString(3, cmbCategoria.getSelectedItem().toString()); // Tipo_Producto
        ps.setString(4, cmbTipo.getSelectedItem().toString()); // Material_Producto
        ps.setString(5, txtDescripcion.getText()); // Descripcion_Producto
        ps.setString(6, cmbTalla.getSelectedItem().toString()); // Talla_Producto
        ps.setInt(7, Integer.parseInt(txtCantidad.getText())); // Cantidad_Disponible
        ps.executeUpdate();
        JOptionPane.showMessageDialog(null, "¡Producto insertado correctamente!");
        con.close();
        } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al insertar: " + e.getMessage());
        } catch (NumberFormatException nfe) {
        JOptionPane.showMessageDialog(null, "La cantidad debe ser un número válido.");
    }
}
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ActualizarExistencias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAtrasAcE;
    private javax.swing.JButton btnSubirExistencias;
    private javax.swing.JComboBox<String> cmbCategoria;
    private javax.swing.JComboBox<String> cmbInsertarProducto;
    private javax.swing.JComboBox<String> cmbTalla;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtProveedor;
    // End of variables declaration//GEN-END:variables
}
